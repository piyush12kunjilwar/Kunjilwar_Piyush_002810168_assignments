/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.Campus;

/**
 *
 * @author kal bugrara
 */
public class CampusMainExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        0. Create Address object  
        1. create campus object
        2. Create and add buildings
        3. Create and floors
        4. Create and add rooms
        5. Assign sprinkers.
        6. Write methods to determine is campus safe => are builinds safe etc.
*/





    }
    
}
